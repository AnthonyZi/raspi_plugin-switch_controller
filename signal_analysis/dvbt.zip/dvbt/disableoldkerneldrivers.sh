sudo rmmod dvb_usb_rtl28xxu rtl2832 #disable active driver
