sudo rtl_test -t #should not throw any errors
