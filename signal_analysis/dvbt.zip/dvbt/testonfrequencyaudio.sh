rtl_fm -M fm -f 433M -g 20 | play -r 16k -t raw -e s -b 16 -c 1 -V1 -
