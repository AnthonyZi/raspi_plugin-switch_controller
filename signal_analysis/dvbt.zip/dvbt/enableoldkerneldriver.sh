sudo modprobe dvb-usb-rtl28xxu rtl2832 #enable old kernel-driver back again
